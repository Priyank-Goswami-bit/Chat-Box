const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const faqRoutes = require('./routes/faqRoutes');
const chatbotRoutes = require('./routes/chatbotRoutes');
const ticketRoutes = require('./routes/ticketRoutes');
const { notFoundHandler, globalErrorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ success: true, status: 'online', timestamp: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/faqs', faqRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/tickets', ticketRoutes);

// Unknown /api/* paths return a JSON 404
app.use('/api', notFoundHandler);

// Serve the built Angular app (frontend/dist/support-portal/browser) from the same server
const clientDir = path.resolve(__dirname, '../../frontend/dist/support-portal/browser');
if (fs.existsSync(path.join(clientDir, 'index.html'))) {
  app.use(express.static(clientDir));
  app.get('*', (req, res) => res.sendFile(path.join(clientDir, 'index.html')));
} else {
  app.get('/', (req, res) => {
    res.type('text').send(
      'API is running. The frontend is not built yet.\n' +
      'Run "npm run build" in the project root, or "npm run dev:frontend" for the dev server.'
    );
  });
}

app.use(notFoundHandler);
app.use(globalErrorHandler);

module.exports = app;
