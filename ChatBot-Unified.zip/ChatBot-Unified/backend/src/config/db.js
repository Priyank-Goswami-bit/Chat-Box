const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const dbName = () => process.env.DB_NAME || 'support_system';

const baseConfig = () => ({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  charset: 'utf8mb4',
  dateStrings: true,
});

let pool = null;
const getPool = () => {
  if (!pool) throw new Error('Database is not ready. Call initDb() first.');
  return pool;
};

const query = async (sql, params = []) => {
  const [rows] = await getPool().query(sql, params);
  return rows;
};
const get = async (sql, params = []) => (await query(sql, params))[0];
const run = async (sql, params = []) => {
  const [result] = await getPool().query(sql, params);
  return { lastID: result.insertId, changes: result.affectedRows };
};

const initDb = async () => {
  // database na ho to bana do
  const admin = await mysql.createConnection(baseConfig());
  await admin.query(`CREATE DATABASE IF NOT EXISTS \`${dbName()}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await admin.end();

  pool = mysql.createPool({ ...baseConfig(), database: dbName(), waitForConnections: true, connectionLimit: 10 });
  pool.pool.on('connection', (conn) => conn.query("SET time_zone = '+00:00'"));

  // tables bana do
  const schema = fs.readFileSync(path.resolve(__dirname, '../database/schema.sql'), 'utf8');
  const statements = schema.split(';').map((s) => s.replace(/--.*$/gm, '').trim()).filter(Boolean);
  for (const statement of statements) await pool.query(statement);

  console.log(`Connected to MySQL database "${dbName()}"`);
};

module.exports = { query, get, run, initDb, getPool, dbName };