const nodemailer = require('nodemailer');

let transporter = null;

const getTransporter = () => {
  if (transporter) return transporter;

  const host = process.env.EMAIL_HOST || 'smtp.ethereal.email';
  const port = parseInt(process.env.EMAIL_PORT || '587', 10);
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;

  if (user && pass) {
    transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });
  } else {
    // Simulated transporter fallback
    transporter = {
      sendMail: async (mailOptions) => {
        console.log('\n--- [EMAIL SIMULATION NOTIFICATION] ---');
        console.log(`To: ${mailOptions.to}`);
        console.log(`Subject: ${mailOptions.subject}`);
        console.log(`Body:\n${mailOptions.text || '(HTML email sent)'}`);
        console.log('----------------------------------------\n');
        return { messageId: `mock-${Date.now()}` };
      },
    };
  }

  return transporter;
};

module.exports = { getTransporter };
