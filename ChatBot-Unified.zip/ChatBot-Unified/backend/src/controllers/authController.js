const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { get, run } = require('../config/db');
const { success, error } = require('../utils/response');
const { SELF_SERVE_USER_TYPES } = require('../utils/constants');

const generateToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, user_type: user.user_type },
    process.env.JWT_SECRET || 'dev_only_secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/auth/register  (buyer / broker / builder only; admins are created by the seed)
const register = async (req, res) => {
  try {
    const { name, email, password, user_type = 'buyer' } = req.body;

    if (!name || !email || !password) {
      return error(res, 'Please provide name, email and password.', 400);
    }
    if (!EMAIL_RE.test(email)) {
      return error(res, 'Please enter a valid email address.', 400);
    }
    if (password.length < 6) {
      return error(res, 'Password must be at least 6 characters.', 400);
    }
    if (!SELF_SERVE_USER_TYPES.includes(user_type)) {
      return error(res, `Account type must be one of: ${SELF_SERVE_USER_TYPES.join(', ')}.`, 400);
    }

    const cleanEmail = email.toLowerCase().trim();
    const existing = await get('SELECT id FROM users WHERE email = ?', [cleanEmail]);
    if (existing) {
      return error(res, 'An account with this email already exists.', 400);
    }

    const hashed = await bcrypt.hash(password, 10);
    const result = await run(
      'INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, ?)',
      [name.trim(), cleanEmail, hashed, user_type]
    );

    const user = await get('SELECT id, name, email, user_type, created_at FROM users WHERE id = ?', [result.lastID]);
    return success(res, { user, token: generateToken(user) }, 'Account created.', 201);
  } catch (err) {
    console.error('Registration error:', err);
    return error(res, 'Failed to create account.', 500);
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return error(res, 'Please provide email and password.', 400);
    }

    const row = await get('SELECT * FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (!row || !(await bcrypt.compare(password, row.password))) {
      return error(res, 'Invalid email or password.', 401);
    }

    const user = { id: row.id, name: row.name, email: row.email, user_type: row.user_type, created_at: row.created_at };
    return success(res, { user, token: generateToken(user) }, 'Login successful.');
  } catch (err) {
    console.error('Login error:', err);
    return error(res, 'Failed to log in.', 500);
  }
};

// GET /api/auth/me
const me = (req, res) => success(res, { user: req.user }, 'Current user.');

module.exports = { register, login, me };
