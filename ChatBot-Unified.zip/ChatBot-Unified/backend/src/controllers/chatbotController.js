const { matchFaq, inferCategory, checkSensitiveData } = require('../services/chatbotService');
const { success, error } = require('../utils/response');

// POST /api/chatbot/ask
const askChatbot = async (req, res) => {
  try {
    const { question } = req.body;

    if (!question || typeof question !== 'string' || !question.trim()) {
      return error(res, 'Please provide a question in the request body.', 400);
    }

    const cleanQuestion = question.trim();

    // Check for quick greetings
    const lower = cleanQuestion.toLowerCase();
    const greetings = ['hi', 'hello', 'hey', 'namaste', 'good morning', 'good afternoon', 'good evening'];
    if (greetings.includes(lower)) {
      return success(res, {
        matched: true,
        confidence: 1.0,
        answer: "Hello! 👋 I'm your virtual support assistant. How can I help you today? You can ask about payments, KYC, account settings, or listing your project. If needed, you can also raise a support ticket!",
        suggestRaiseTicket: false,
        securityWarning: null,
      });
    }

    // Direct user request to raise ticket
    if (lower.includes('raise ticket') || lower.includes('create ticket') || lower.includes('talk to human') || lower.includes('speak to agent') || lower.includes('support team')) {
      const suggestedCategory = inferCategory(cleanQuestion);
      return success(res, {
        matched: false,
        confidence: 1.0,
        answer: "Sure! You can submit a support ticket directly and our customer service team will assist you.",
        suggestRaiseTicket: true,
        suggestedCategory,
        suggestedSubject: cleanQuestion,
        securityWarning: checkSensitiveData(cleanQuestion),
      });
    }

    const result = await matchFaq(cleanQuestion);

    return success(res, result, 'Chatbot response generated.');
  } catch (err) {
    console.error('Error processing chatbot ask:', err);
    return error(res, 'Failed to process your question.', 500);
  }
};

module.exports = {
  askChatbot,
};
