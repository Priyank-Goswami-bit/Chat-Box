const { query, get, run } = require('../config/db');
const { success, error } = require('../utils/response');
const { CATEGORIES } = require('../utils/constants');

// GET /api/faqs - Public / User access
const getAllFaqs = async (req, res) => {
  try {
    const { category, search } = req.query;
    let sql = 'SELECT * FROM faqs WHERE 1=1';
    const params = [];

    if (category) {
      sql += ' AND LOWER(category) = LOWER(?)';
      params.push(category);
    }

    if (search) {
      sql += ' AND (question LIKE ? OR keywords LIKE ? OR answer LIKE ?)';
      const term = `%${search}%`;
      params.push(term, term, term);
    }

    sql += ' ORDER BY id ASC';
    const faqs = await query(sql, params);

    return success(res, faqs, 'FAQs retrieved successfully.');
  } catch (err) {
    console.error('Error fetching FAQs:', err);
    return error(res, 'Failed to fetch FAQs.', 500);
  }
};

// GET /api/faqs/:id - Get single FAQ
const getFaqById = async (req, res) => {
  try {
    const { id } = req.params;
    const faq = await get('SELECT * FROM faqs WHERE id = ?', [id]);

    if (!faq) {
      return error(res, 'FAQ not found.', 404);
    }

    return success(res, faq, 'FAQ details.');
  } catch (err) {
    console.error('Error fetching FAQ by id:', err);
    return error(res, 'Failed to fetch FAQ details.', 500);
  }
};

// POST /api/faqs - Admin adds FAQ
const createFaq = async (req, res) => {
  try {
    const { question, answer, category, keywords } = req.body;

    if (!question || !answer || !category) {
      return error(res, 'Question, answer, and category are required.', 400);
    }
    if (!CATEGORIES.includes(category.trim())) {
      return error(res, `Category must be one of: ${CATEGORIES.join(', ')}.`, 400);
    }

    const kw = Array.isArray(keywords) ? keywords.join(', ') : (keywords || '');

    const result = await run(
      'INSERT INTO faqs (question, answer, category, keywords, created_at, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)',
      [question.trim(), answer.trim(), category.trim(), kw.trim()]
    );

    const newFaq = await get('SELECT * FROM faqs WHERE id = ?', [result.lastID]);
    return success(res, newFaq, 'FAQ created successfully.', 201);
  } catch (err) {
    console.error('Error creating FAQ:', err);
    return error(res, 'Failed to create FAQ.', 500);
  }
};

// PUT /api/faqs/:id - Admin edits FAQ
const updateFaq = async (req, res) => {
  try {
    const { id } = req.params;
    const { question, answer, category, keywords } = req.body;

    const existingFaq = await get('SELECT * FROM faqs WHERE id = ?', [id]);
    if (!existingFaq) {
      return error(res, 'FAQ not found.', 404);
    }

    if (category !== undefined && !CATEGORIES.includes(category.trim())) {
      return error(res, `Category must be one of: ${CATEGORIES.join(', ')}.`, 400);
    }

    const updatedQuestion = question !== undefined ? question.trim() : existingFaq.question;
    const updatedAnswer = answer !== undefined ? answer.trim() : existingFaq.answer;
    const updatedCategory = category !== undefined ? category.trim() : existingFaq.category;
    const updatedKeywords = keywords !== undefined
      ? (Array.isArray(keywords) ? keywords.join(', ') : keywords.trim())
      : existingFaq.keywords;

    await run(
      'UPDATE faqs SET question = ?, answer = ?, category = ?, keywords = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [updatedQuestion, updatedAnswer, updatedCategory, updatedKeywords, id]
    );

    const updated = await get('SELECT * FROM faqs WHERE id = ?', [id]);
    return success(res, updated, 'FAQ updated successfully.');
  } catch (err) {
    console.error('Error updating FAQ:', err);
    return error(res, 'Failed to update FAQ.', 500);
  }
};

// DELETE /api/faqs/:id - Admin deletes FAQ
const deleteFaq = async (req, res) => {
  try {
    const { id } = req.params;
    const faq = await get('SELECT * FROM faqs WHERE id = ?', [id]);

    if (!faq) {
      return error(res, 'FAQ not found.', 404);
    }

    await run('DELETE FROM faqs WHERE id = ?', [id]);
    return success(res, { id: Number(id) }, 'FAQ deleted successfully.');
  } catch (err) {
    console.error('Error deleting FAQ:', err);
    return error(res, 'Failed to delete FAQ.', 500);
  }
};

module.exports = {
  getAllFaqs,
  getFaqById,
  createFaq,
  updateFaq,
  deleteFaq,
};
