const { query, get, run } = require('../config/db');
const { success, error } = require('../utils/response');
const { CATEGORIES, STATUSES } = require('../utils/constants');
const {
  sendTicketCreatedNotification,
  sendTicketReplyNotification,
  sendTicketStatusNotification,
} = require('../services/emailService');

const TICKET_WITH_PEOPLE = `
  SELECT t.*, u.name AS user_name, u.email AS user_email, a.name AS assignee_name,
         (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id AND m.sender_role = 'admin') AS admin_reply_count
  FROM tickets t
  LEFT JOIN users u ON t.user_id = u.id
  LEFT JOIN users a ON t.assigned_to = a.id
`;

const randomTicketCode = () => `TCK-${Math.floor(100000 + Math.random() * 900000)}`;

const uniqueTicketCode = async () => {
  for (let i = 0; i < 10; i += 1) {
    const code = randomTicketCode();
    if (!(await get('SELECT id FROM tickets WHERE ticket_code = ?', [code]))) return code;
  }
  return `TCK-${Date.now()}`;
};

// POST /api/tickets
const createTicket = async (req, res) => {
  try {
    const { category, subject, description } = req.body;

    if (!category || !subject || !description || !subject.trim() || !description.trim()) {
      return error(res, 'Category, subject and description are required.', 400);
    }
    if (!CATEGORIES.includes(category)) {
      return error(res, `Category must be one of: ${CATEGORIES.join(', ')}.`, 400);
    }

    const ticketCode = await uniqueTicketCode();
    const insert = await run(
      `INSERT INTO tickets (ticket_code, user_id, user_type, category, subject, description, status)
       VALUES (?, ?, ?, ?, ?, ?, 'Open')`,
      [ticketCode, req.user.id, req.user.user_type, category, subject.trim(), description.trim()]
    );

    // The description is also the first message of the conversation thread
    await run(
      `INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, sender_name, message)
       VALUES (?, ?, ?, ?, ?)`,
      [insert.lastID, req.user.id, req.user.user_type === 'admin' ? 'admin' : 'user', req.user.name, description.trim()]
    );

    const ticket = await get('SELECT * FROM tickets WHERE id = ?', [insert.lastID]);
    sendTicketCreatedNotification(ticket, req.user); // fire and forget

    return success(res, ticket, 'Ticket created.', 201);
  } catch (err) {
    console.error('Error creating ticket:', err);
    return error(res, 'Failed to create ticket.', 500);
  }
};

// GET /api/tickets/my
const getMyTickets = async (req, res) => {
  try {
    const { status, category } = req.query;
    let sql = `${TICKET_WITH_PEOPLE} WHERE t.user_id = ?`;
    const params = [req.user.id];

    if (status) { sql += ' AND LOWER(t.status) = LOWER(?)'; params.push(status); }
    if (category) { sql += ' AND LOWER(t.category) = LOWER(?)'; params.push(category); }

    sql += ' ORDER BY t.updated_at DESC, t.id DESC';
    return success(res, await query(sql, params), 'Your tickets.');
  } catch (err) {
    console.error('Error fetching user tickets:', err);
    return error(res, 'Failed to fetch tickets.', 500);
  }
};

// GET /api/tickets  (admin, with filters)
const getAllTicketsAdmin = async (req, res) => {
  try {
    const { status, category, user_type, dateFrom, dateTo, search, assigned_to } = req.query;
    let sql = `${TICKET_WITH_PEOPLE} WHERE 1=1`;
    const params = [];

    if (status) { sql += ' AND t.status = ?'; params.push(status); }
    if (category) { sql += ' AND t.category = ?'; params.push(category); }
    if (user_type) { sql += ' AND t.user_type = ?'; params.push(user_type); }
    if (assigned_to === 'none') { sql += ' AND t.assigned_to IS NULL'; }
    else if (assigned_to) { sql += ' AND t.assigned_to = ?'; params.push(assigned_to); }
    if (dateFrom) { sql += ' AND DATE(t.created_at) >= DATE(?)'; params.push(dateFrom); }
    if (dateTo) { sql += ' AND DATE(t.created_at) <= DATE(?)'; params.push(dateTo); }
    if (search) {
      sql += ' AND (t.ticket_code LIKE ? OR t.subject LIKE ? OR t.description LIKE ? OR u.name LIKE ? OR u.email LIKE ?)';
      const term = `%${search}%`;
      params.push(term, term, term, term, term);
    }

    sql += ' ORDER BY t.created_at DESC, t.id DESC';
    return success(res, await query(sql, params), 'Tickets.');
  } catch (err) {
    console.error('Error fetching admin tickets:', err);
    return error(res, 'Failed to fetch tickets.', 500);
  }
};

// GET /api/tickets/stats  (admin)
const getTicketStats = async (req, res) => {
  try {
    const rows = await query('SELECT status, COUNT(*) AS count FROM tickets GROUP BY status');
    const stats = { total: 0 };
    STATUSES.forEach((s) => { stats[s] = 0; });
    rows.forEach((r) => { stats[r.status] = r.count; stats.total += r.count; });
    return success(res, stats, 'Ticket stats.');
  } catch (err) {
    console.error('Error fetching stats:', err);
    return error(res, 'Failed to fetch stats.', 500);
  }
};

// GET /api/tickets/:id  (owner or admin) - includes the conversation
const getTicketById = async (req, res) => {
  try {
    const { id } = req.params;
    const ticket = await get(`${TICKET_WITH_PEOPLE} WHERE t.id = ? OR t.ticket_code = ?`, [id, id]);
    if (!ticket) return error(res, 'Ticket not found.', 404);

    if (req.user.user_type !== 'admin' && ticket.user_id !== req.user.id) {
      return error(res, 'You can only view your own tickets.', 403);
    }

    const messages = await query(
      'SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC, id ASC',
      [ticket.id]
    );
    return success(res, { ...ticket, messages }, 'Ticket details.');
  } catch (err) {
    console.error('Error fetching ticket:', err);
    return error(res, 'Failed to fetch ticket.', 500);
  }
};

// POST /api/tickets/:id/reply  (owner or admin)
const addReply = async (req, res) => {
  try {
    const { id } = req.params;
    const { message } = req.body;
    if (!message || !message.trim()) {
      return error(res, 'Reply cannot be empty.', 400);
    }

    const ticket = await get('SELECT * FROM tickets WHERE id = ? OR ticket_code = ?', [id, id]);
    if (!ticket) return error(res, 'Ticket not found.', 404);

    const isAdmin = req.user.user_type === 'admin';
    if (!isAdmin && ticket.user_id !== req.user.id) {
      return error(res, 'You cannot reply to this ticket.', 403);
    }
    if (ticket.status === 'Closed') {
      return error(res, 'This ticket is closed. Raise a new ticket if you still need help.', 400);
    }

    const insert = await run(
      `INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, sender_name, message)
       VALUES (?, ?, ?, ?, ?)`,
      [ticket.id, req.user.id, isAdmin ? 'admin' : 'user', req.user.name, message.trim()]
    );

    // Admin's first reply starts work; a customer reply on a resolved ticket reopens it
    let status = ticket.status;
    if (isAdmin && status === 'Open') status = 'In Progress';
    if (!isAdmin && status === 'Resolved') status = 'Open';
    await run('UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [status, ticket.id]);

    const newMessage = await get('SELECT * FROM ticket_messages WHERE id = ?', [insert.lastID]);

    if (isAdmin) {
      const owner = await get('SELECT name, email FROM users WHERE id = ?', [ticket.user_id]);
      if (owner) sendTicketReplyNotification(ticket, newMessage, owner.email, owner.name, req.user.name, 'Support Team');
    } else {
      const adminEmail = process.env.ADMIN_EMAIL || 'admin@support.com';
      sendTicketReplyNotification(ticket, newMessage, adminEmail, 'Support Team', req.user.name, ticket.user_type);
    }

    return success(res, { ...newMessage, ticket_status: status }, 'Reply sent.', 201);
  } catch (err) {
    console.error('Error adding reply:', err);
    return error(res, 'Failed to send reply.', 500);
  }
};

// PATCH /api/tickets/:id  (admin) - status and/or assignee
const updateTicketStatusOrAssign = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, assigned_to } = req.body;

    const ticket = await get('SELECT * FROM tickets WHERE id = ? OR ticket_code = ?', [id, id]);
    if (!ticket) return error(res, 'Ticket not found.', 404);

    const updates = [];
    const params = [];
    let statusChanged = false;

    if (status !== undefined) {
      if (!STATUSES.includes(status)) {
        return error(res, `Status must be one of: ${STATUSES.join(', ')}.`, 400);
      }
      updates.push('status = ?');
      params.push(status);
      statusChanged = status !== ticket.status;
    }

    if (assigned_to !== undefined) {
      if (assigned_to !== null) {
        const assignee = await get("SELECT id FROM users WHERE id = ? AND user_type = 'admin'", [assigned_to]);
        if (!assignee) return error(res, 'Assignee must be a support admin.', 400);
      }
      updates.push('assigned_to = ?');
      params.push(assigned_to);
    }

    if (updates.length === 0) {
      return error(res, 'Provide status and/or assigned_to.', 400);
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    params.push(ticket.id);
    await run(`UPDATE tickets SET ${updates.join(', ')} WHERE id = ?`, params);

    const updated = await get(`${TICKET_WITH_PEOPLE} WHERE t.id = ?`, [ticket.id]);

    if (statusChanged) {
      const owner = await get('SELECT name, email FROM users WHERE id = ?', [ticket.user_id]);
      if (owner) sendTicketStatusNotification(updated, owner, status);
    }

    return success(res, updated, 'Ticket updated.');
  } catch (err) {
    console.error('Error updating ticket:', err);
    return error(res, 'Failed to update ticket.', 500);
  }
};

module.exports = {
  createTicket,
  getMyTickets,
  getAllTicketsAdmin,
  getTicketStats,
  getTicketById,
  addReply,
  updateTicketStatusOrAssign,
};
