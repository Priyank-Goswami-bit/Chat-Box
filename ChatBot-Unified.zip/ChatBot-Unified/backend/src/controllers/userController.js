const { query } = require('../config/db');
const { success, error } = require('../utils/response');

// GET /api/users/staff - admins that tickets can be assigned to
const getStaff = async (req, res) => {
  try {
    const staff = await query("SELECT id, name FROM users WHERE user_type = 'admin' ORDER BY name ASC");
    return success(res, staff, 'Staff list.');
  } catch (err) {
    console.error('Error fetching staff:', err);
    return error(res, 'Failed to fetch staff.', 500);
  }
};

module.exports = { getStaff };
