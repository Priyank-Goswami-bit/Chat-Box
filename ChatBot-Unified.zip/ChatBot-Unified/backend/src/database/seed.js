require('dotenv').config();
const bcrypt = require('bcryptjs');
const { initDb, run, query } = require('../config/db');

// Chatbot knowledge base. Admins can add/edit/delete these later from the dashboard.
  const faqs = [
    // Category: Login & Account
    {
      question: 'How do I reset my account password?',
      answer: 'To reset your password, click on the "Forgot Password" link on the login screen. Enter your registered email address, and you will receive an OTP and password reset link within 2 minutes.',
      category: 'Account issue',
      keywords: 'password, reset, forgot, login, change password, credentials, otp',
    },
    {
      question: 'I am not receiving the login OTP on my phone or email. What should I do?',
      answer: 'Please ensure your network connection is stable and check your spam/junk folder for email OTP. If the OTP is still not received after 60 seconds, click "Resend OTP". If the issue persists, please raise a support ticket.',
      category: 'Account issue',
      keywords: 'otp, not received, sms, email otp, verification code, login otp',
    },
    {
      question: 'How can I update my profile details and mobile number?',
      answer: 'Navigate to "My Account" > "Profile Settings". You can update your display name, company name, and secondary phone. For primary mobile number changes, a security OTP verification is required.',
      category: 'Account issue',
      keywords: 'profile, mobile, phone number, update, edit profile, change email',
    },
    {
      question: 'Can I change my registered user type from Buyer to Broker or Builder?',
      answer: 'User type changes require manual verification. Please raise a ticket with category "Account issue" attaching your broker license or builder business registration certificate.',
      category: 'Account issue',
      keywords: 'change role, user type, buyer to broker, builder, switch account',
    },
    {
      question: 'How do I delete or deactivate my account?',
      answer: 'To deactivate your account, go to "Settings" > "Privacy & Security" > "Deactivate Account". Note that active property listings and pending ticket conversations will be closed.',
      category: 'Account issue',
      keywords: 'delete account, deactivate, remove account, close account',
    },

    // Category: Payment & Billing
    {
      question: 'What payment methods are supported on the platform?',
      answer: 'We support all major payment modes including UPI (Google Pay, PhonePe, Paytm), Credit and Debit Cards (Visa, MasterCard, RuPay), Net Banking across 50+ banks, and Wallets.',
      category: 'Payment issue',
      keywords: 'payment methods, upi, cards, net banking, visa, mastercard, payment modes',
    },
    {
      question: 'My payment was debited from my bank, but the plan is not activated. What should I do?',
      answer: 'Usually, bank reconciliation takes 15 to 30 minutes. If your plan is not activated within 1 hour, please raise a ticket under "Payment issue" with your Bank Transaction Reference ID (UTR / RRN).',
      category: 'Payment issue',
      keywords: 'payment debited, money deducted, plan not active, payment failure, utr, rrn',
    },
    {
      question: 'How do I download my payment invoice or GST bill?',
      answer: 'Go to "My Account" > "Billing & Invoices". You will find the complete list of transactions with downloadable PDF tax invoices including your business GST details.',
      category: 'Payment issue',
      keywords: 'invoice, bill, gst, receipt, download invoice, tax invoice',
    },
    {
      question: 'What is the refund policy for premium subscriptions?',
      answer: 'Refund requests must be initiated within 48 hours of purchase if no listings or lead contacts have been consumed. Approved refunds are credited back to the original payment source within 5–7 business days.',
      category: 'Payment issue',
      keywords: 'refund, money back, cancellation refund, return payment',
    },
    {
      question: 'Why did my online payment fail at checkout?',
      answer: 'Payment failures commonly happen due to bank server timeouts, incorrect CVV/OTP, or daily online transaction limits. Try using an alternate UPI ID or card. If charged, amount is auto-reversed in 3-5 days.',
      category: 'Payment issue',
      keywords: 'payment failed, transaction failed, declined, checkout error',
    },

    // Category: Premium Plan
    {
      question: 'What are the benefits of upgrading to a Premium Plan?',
      answer: 'Premium plans offer higher listing visibility, verified badges, priority search ranking, direct buyer contact numbers, advanced lead analytics, and dedicated support account managers.',
      category: 'Payment issue',
      keywords: 'premium plan, subscription, upgrade, benefits, pro features, features',
    },
    {
      question: 'How long is a Premium Plan valid and how can I renew it?',
      answer: 'Subscriptions are available in 1-month, 3-month, and annual packages. You can renew at any time from "Billing" > "Renew Plan". Auto-renewal can also be enabled or disabled anytime.',
      category: 'Payment issue',
      keywords: 'validity, renew, subscription period, expiry, auto renew',
    },
    {
      question: 'Can I upgrade my current plan to a higher tier before expiry?',
      answer: 'Yes! When upgrading to a higher plan mid-cycle, the unused balance of your existing plan is automatically calculated and adjusted as a discount against the new plan.',
      category: 'Payment issue',
      keywords: 'upgrade plan, tier change, prorated, higher plan, change subscription',
    },
    {
      question: 'Do unused lead contacts or listing slots roll over to the next month?',
      answer: 'If you renew your premium subscription before the expiry date, unused listing slots and lead credits roll over to the subsequent billing cycle.',
      category: 'Payment issue',
      keywords: 'rollover, unused leads, slots, carry forward, expire',
    },

    // Category: KYC Verification
    {
      question: 'Which documents are required for KYC verification?',
      answer: 'For individual buyers/brokers: Aadhaar Card / Passport and PAN Card. For builders/firms: Company PAN, Certificate of Incorporation, RERA Registration Certificate, and authorized signatory ID.',
      category: 'KYC issue',
      keywords: 'kyc documents, aadhaar, pan card, passport, rera, verification documents',
    },
    {
      question: 'How much time does it take for KYC verification to be approved?',
      answer: 'Our compliance team reviews KYC submissions within 24 to 48 business hours. You will receive an email and in-app alert once your KYC status is verified or if clarification is needed.',
      category: 'KYC issue',
      keywords: 'kyc time, approval time, verification delay, kyc status, 24 hours',
    },
    {
      question: 'Why was my KYC verification rejected?',
      answer: 'Common reasons for rejection include blurry or unreadable document photos, name mismatch between PAN and registered profile, or expired IDs. Check your email for specific rejection remarks and re-upload clear copies.',
      category: 'KYC issue',
      keywords: 'kyc rejected, rejection reason, invalid document, blurred photo, mismatch',
    },
    {
      question: 'Is it mandatory to complete KYC before contacting sellers or posting properties?',
      answer: 'Browsing is open, but posting properties and accessing verified seller contact details requires at least basic KYC verification to maintain a safe and fraud-free platform.',
      category: 'KYC issue',
      keywords: 'mandatory kyc, why kyc, compulsory, verification required',
    },
    {
      question: 'Can I share my Aadhaar card or bank details in the support chat for verification?',
      answer: 'No! Please do not share Aadhaar, passwords, or bank card details in the chat. All verification documents must be securely uploaded through the official "KYC Verification" portal page.',
      category: 'KYC issue',
      keywords: 'aadhaar in chat, bank details, security warning, safe upload, card details',
    },

    // Category: Project & Property Listing
    {
      question: 'How do I list a new property or project on the platform?',
      answer: 'Click the "Post Property / Project" button in the navigation header. Fill in the property configuration, location, carpet area, expected price, amenities, and upload at least 3 high-quality photographs.',
      category: 'Project listing',
      keywords: 'list property, post property, add project, new listing, sell property',
    },
    {
      question: 'How long does it take for a posted listing to go live?',
      answer: 'Properties posted by KYC-verified users go live within 2 to 4 hours after basic moderation check for genuine pricing and clean images. Builder projects take up to 24 hours for RERA validation.',
      category: 'Project listing',
      keywords: 'listing live, approval time, moderation, review property, pending listing',
    },
    {
      question: 'How can I edit, mark as sold, or delete my existing listing?',
      answer: 'Go to "My Listings" tab on your dashboard. Click the three dots menu on any listing to edit details, adjust the asking price, mark as "Sold / Rented", or permanently delete the listing.',
      category: 'Project listing',
      keywords: 'edit listing, mark sold, delete listing, update property, modify price',
    },
    {
      question: 'What is RERA verification and why is it required for builder projects?',
      answer: 'Under Real Estate Regulatory Authority regulations, all commercial and residential projects spanning over 500 sq. meters or more than 8 apartments must display a valid RERA registration number before marketing.',
      category: 'Project listing',
      keywords: 'rera, rera number, builder validation, regulatory, project approval',
    },
    {
      question: 'Why is my property listing rejected or suspended?',
      answer: 'Listings may be rejected due to copyright-infringing photos, unrealistic pricing, duplicate postings, or incomplete property specifications. Check your email notifications for exact correction steps.',
      category: 'Project listing',
      keywords: 'listing rejected, suspended listing, photo error, duplicate, invalid price',
    },

    // Category: Support & General
    {
      question: 'How do I raise a support ticket if the chatbot cannot resolve my issue?',
      answer: 'You can click the "Raise a Ticket" button directly in the chat widget or go to "Support" > "New Ticket". Select your issue category, enter subject and description, and submit. Our team replies within 4 hours.',
      category: 'Other',
      keywords: 'raise ticket, support ticket, create ticket, contact team, help desk, assistance',
    },
    {
      question: 'Where can I track the status and replies of my submitted tickets?',
      answer: 'You can view all past and ongoing requests under the "My Tickets" section in the menu. Click on any ticket to view the conversation thread, admin updates, and reply with further details.',
      category: 'Other',
      keywords: 'my tickets, track status, ticket history, ticket replies, check ticket',
    },
    {
      question: 'What are the official customer support operating hours?',
      answer: 'Our digital chatbot and ticket submission portal operate 24/7. Our live support team handles tickets Monday through Saturday from 9:00 AM to 8:00 PM IST.',
      category: 'Other',
      keywords: 'support hours, working hours, timings, holiday, customer care',
    },
    {
    question: 'How do I change my registered email address?',
    answer: 'Go to My Account > Profile Settings and click Edit next to your email. A verification OTP will be sent to the new address. Enter it to confirm the change.',
    category: 'Account issue',
    keywords: 'change email, update email, registered email, email address, edit email, modify email, email change, profile email, new email',
  },
  {
    question: 'Why is my account locked after multiple login attempts?',
    answer: 'For security, your account is locked for 30 minutes after 5 failed login attempts. Wait for 30 minutes or use the Forgot Password option to reset your password immediately.',
    category: 'Account issue',
    keywords: 'account locked, account blocked, login failed, login attempts, failed login, too many attempts, locked account, blocked account, login problem, unable to login',
  },
  {
    question: 'How can I enable two-step verification?',
    answer: 'Open My Account > Security and turn on Two-Step Verification. You will receive an OTP on your registered mobile number every time you log in from a new device.',
    category: 'Account issue',
    keywords: 'two step verification, 2fa, two factor authentication, security, otp, login protection, account security, verification code, mobile otp',
  },
  {
    question: 'How do I change my account password?',
    answer: 'Go to My Account > Security > Change Password. Enter your current password, then your new password twice and click Save. Use at least 8 characters with a number and a symbol.',
    category: 'Account issue',
    keywords: 'change password, update password, reset password, new password, password change, password update, forgot password, account password, security password',
  },

  // Category: Payment issue
  {
    question: 'How do I upgrade my premium plan?',
    answer: 'Go to My Account > Billing & Plans and select Upgrade. The remaining balance of your current plan is adjusted automatically.',
    category: 'Payment issue',
    keywords: 'upgrade plan, premium plan, upgrade subscription, change plan, higher plan, premium upgrade, subscription upgrade, billing plan, plan upgrade',
  },
  {
    question: 'Will I get a GST invoice for my subscription?',
    answer: 'Yes. A GST invoice is generated automatically after every successful payment. You can download it from My Account > Billing & Invoices.',
    category: 'Payment issue',
    keywords: 'gst invoice, gst bill, tax invoice, invoice, payment receipt, receipt, billing invoice, subscription invoice, tax bill',
  },
  {
    question: 'My money was deducted but the transaction shows failed. What should I do?',
    answer: 'Failed transactions are usually auto-reversed by your bank within 5 to 7 working days. If the amount is not credited after that, raise a ticket with your transaction ID and bank statement screenshot.',
    category: 'Payment issue',
    keywords: 'money deducted, payment failed, transaction failed, amount deducted, payment stuck, failed transaction, refund, reversal, money not refunded, payment issue, bank transaction',
  },
  {
    question: 'Can I cancel my subscription and get a refund?',
    answer: 'You can cancel anytime from Billing & Plans. Refunds are available only if requested within 48 hours of purchase and no premium features have been used.',
    category: 'Payment issue',
    keywords: 'cancel subscription, cancel plan, subscription cancellation, refund, money back, refund request, cancellation policy, cancel premium, payment refund',
  },

  // Category: KYC issue
  {
    question: 'How do I verify my KYC through DigiLocker?',
    answer: 'Open the KYC section in your profile, choose DigiLocker, log in with your Aadhaar-linked mobile number and approve access. Verification usually completes within a few minutes.',
    category: 'KYC issue',
    keywords: 'kyc, kyc verification, digilocker, aadhaar, aadhaar verification, verify kyc, kyc process, identity verification, document verification',
  },
  {
    question: 'Can I update my KYC details after verification?',
    answer: 'Verified KYC details cannot be edited directly. Please raise a support ticket with the correct documents and our compliance team will review your request.',
    category: 'KYC issue',
    keywords: 'update kyc, edit kyc, change kyc, modify kyc, correct kyc details, kyc details, reverify kyc, kyc correction, verification details',
  },
  {
    question: 'My KYC is stuck in pending status. What should I do?',
    answer: 'KYC review normally takes up to 24 to 48 working hours. If it is pending for longer, make sure your documents are clear and valid, then raise a ticket with your registered email.',
    category: 'KYC issue',
    keywords: 'kyc pending, kyc stuck, kyc under review, verification pending, kyc verification delay, kyc status, pending verification, kyc not approved, kyc processing',
  },
  {
    question: 'What is the file size and format allowed for KYC documents?',
    answer: 'You can upload JPG, PNG or PDF files up to 5 MB each. Ensure all four corners are visible and the text is readable without glare or blur.',
    category: 'KYC issue',
    keywords: 'kyc upload, kyc documents, document size, file size, upload limit, document format, jpg, jpeg, png, pdf, 5 mb, document upload',
  },

  // Category: Project listing
  {
    question: 'Can I add multiple photos to my property listing?',
    answer: 'Yes. You can upload up to 10 photos per listing in JPG or PNG format, each under 5 MB. Clear, well-lit photos help your listing get more views.',
    category: 'Project listing',
    keywords: 'property photos, listing photos, multiple photos, upload photos, property images, listing images, gallery, photo upload, images, pictures',
  },
  {
    question: 'How can I mark my property as sold or rented?',
    answer: 'Go to My Listings, open the property and click Mark as Sold or Mark as Rented. The listing will be removed from search results but stays in your dashboard for records.',
    category: 'Project listing',
    keywords: 'mark sold, mark rented, property sold, property rented, sold property, rented property, deactivate listing, close listing, remove listing',
  },
  {
    question: 'Why is my listing not visible in search results?',
    answer: 'New listings go through a quick review before going live. Listings may also be hidden if KYC is incomplete, the plan has expired or the photos and details are incomplete.',
    category: 'Project listing',
    keywords: 'listing not visible, listing not showing, property not visible, search results, hidden listing, listing missing, property missing, listing approval, listing review',
  },
  {
    question: 'How do I boost my listing to get more leads?',
    answer: 'Open My Listings and click Boost on the property you want to promote. Boosted listings appear higher in search results for the selected period, and this is available on premium plans.',
    category: 'Project listing',
    keywords: 'boost listing, promote listing, more leads, get leads, featured listing, premium listing, listing promotion, increase visibility, property promotion',
  },

  // Category: Other
  {
    question: 'How can I contact customer support?',
    answer: 'You can raise a ticket from the chat widget or email us at support@searchbhoomi.com. Our team replies within 24 hours.',
    category: 'Other',
    keywords: 'contact support, customer support, help, customer care, support team, raise ticket, support ticket, email support, help desk',
  },
  {
    question: 'What are your support working hours?',
    answer: 'Our support team is available Monday to Saturday, 10 AM to 7 PM IST. Tickets raised outside these hours are answered on the next working day.',
    category: 'Other',
    keywords: 'support hours, working hours, support timing, customer care timing, support availability, help desk hours, working time, customer support hours',
  },
  {
    question: 'How do I report a fake or fraudulent listing?',
    answer: 'Open the listing and click Report this listing, then select the reason. You can also raise a ticket with the listing link. Our team investigates reports within 48 hours.',
    category: 'Other',
    keywords: 'report listing, fake listing, fraudulent listing, fraud, scam, fake property, report fraud, complain, complaint, suspicious listing, report property',
  },
  {
    question: 'How do I delete my account permanently?',
    answer: 'Go to Settings > Privacy & Security > Delete Account. Your data is removed after 30 days. Active subscriptions must be cancelled before deletion, and refunds are not applicable.',
    category: 'Other',
    keywords: 'delete account, remove account, close account, deactivate account, permanently delete, account deletion, delete profile, privacy, close profile',
  },
  ];

const seedEssentials = async () => {
  // First admin account (credentials come from .env)
  const admins = await query("SELECT id FROM users WHERE user_type = 'admin'");
  if (admins.length === 0) {
    const name = process.env.ADMIN_NAME || 'Super Admin';
    const email = (process.env.ADMIN_EMAIL || 'admin@support.com').toLowerCase();
    const password = process.env.ADMIN_PASSWORD || 'Admin@123';
    const hashed = await bcrypt.hash(password, 10);
    await run('INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, ?)', [name, email, hashed, 'admin']);
    console.log(`Created admin account: ${email}`);
  }

  // Starter FAQs, only when the table is empty
  const existing = await query('SELECT id FROM faqs LIMIT 1');
  if (existing.length === 0) {
    for (const faq of faqs) {
      await run(
        'INSERT INTO faqs (question, answer, category, keywords) VALUES (?, ?, ?, ?)',
        [faq.question, faq.answer, faq.category, faq.keywords]
      );
    }
    console.log(`Added ${faqs.length} starter FAQs.`);
  }
};

module.exports = { seedEssentials };

// `npm run seed` runs this file directly
if (require.main === module) {
  initDb()
    .then(seedEssentials)
    .then(() => { console.log('Seed complete.'); process.exit(0); })
    .catch((err) => { console.error('Seed failed:', err); process.exit(1); });
}
