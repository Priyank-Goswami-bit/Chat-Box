const jwt = require('jsonwebtoken');
const { get } = require('../config/db');
const { error } = require('../utils/response');

const JWT_SECRET = () => process.env.JWT_SECRET || 'dev_only_secret';

const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return error(res, 'Authentication required. Please log in.', 401);
    }

    const decoded = jwt.verify(header.split(' ')[1], JWT_SECRET());
    const user = await get('SELECT id, name, email, user_type FROM users WHERE id = ?', [decoded.id]);
    if (!user) {
      return error(res, 'Account no longer exists. Please log in again.', 401);
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return error(res, 'Session expired. Please log in again.', 401);
    }
    return error(res, 'Invalid session. Please log in again.', 401);
  }
};

const authorize = (...allowedRoles) => (req, res, next) => {
  if (!req.user) return error(res, 'Please log in first.', 401);
  if (!allowedRoles.includes(req.user.user_type)) {
    return error(res, 'You do not have permission to do this.', 403);
  }
  next();
};

module.exports = { authenticate, authorize };
