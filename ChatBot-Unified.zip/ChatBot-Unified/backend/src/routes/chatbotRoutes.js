const express = require('express');
const router = express.Router();
const chatbotController = require('../controllers/chatbotController');

// POST /api/chatbot/ask
router.post('/ask', chatbotController.askChatbot);

module.exports = router;
