const express = require('express');
const router = express.Router();
const faqController = require('../controllers/faqController');
const { authenticate, authorize } = require('../middleware/auth');

// Public route to view FAQs
router.get('/', faqController.getAllFaqs);
router.get('/:id', faqController.getFaqById);

// Admin-only management routes
router.post('/', authenticate, authorize('admin'), faqController.createFaq);
router.put('/:id', authenticate, authorize('admin'), faqController.updateFaq);
router.delete('/:id', authenticate, authorize('admin'), faqController.deleteFaq);

module.exports = router;
