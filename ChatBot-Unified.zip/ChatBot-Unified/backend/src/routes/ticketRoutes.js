const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const { authenticate, authorize } = require('../middleware/auth');

// Customer routes
router.post('/', authenticate, ticketController.createTicket);
router.get('/my', authenticate, ticketController.getMyTickets);

// Admin routes (must stay above '/:id')
router.get('/', authenticate, authorize('admin'), ticketController.getAllTicketsAdmin);
router.get('/stats', authenticate, authorize('admin'), ticketController.getTicketStats);

// Owner or admin
router.get('/:id', authenticate, ticketController.getTicketById);
router.post('/:id/reply', authenticate, ticketController.addReply);

// Admin: change status / assign
router.patch('/:id', authenticate, authorize('admin'), ticketController.updateTicketStatusOrAssign);

module.exports = router;
