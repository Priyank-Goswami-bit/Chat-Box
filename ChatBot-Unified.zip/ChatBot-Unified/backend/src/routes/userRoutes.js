const express = require('express');
const router = express.Router();
const { getStaff } = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/staff', authenticate, authorize('admin'), getStaff);

module.exports = router;
