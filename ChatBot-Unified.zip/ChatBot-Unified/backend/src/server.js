require('dotenv').config();
const http = require('http');
const app = require('./app');
const { initDb } = require('./config/db');
const { seedEssentials } = require('./database/seed');

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await initDb();
    await seedEssentials(); // creates the first admin + chatbot FAQs only if they don't exist yet

    const server = http.createServer(app);
    server.listen(PORT, () => {
      console.log('--------------------------------------------------');
      console.log(`Support system running at http://localhost:${PORT}`);
      console.log('--------------------------------------------------');
    });

    const shutdown = () => {
      server.close(() => process.exit(0));
    };
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  } catch (error) {
    console.error('Fatal error starting server:', error);
    process.exit(1);
  }
};

startServer();
