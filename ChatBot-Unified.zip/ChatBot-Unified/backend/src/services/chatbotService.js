const { query } = require('../config/db');

// Common English stopwords to filter out
const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren',
  'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',

  'can', 'cannot', 'could', 'did', 'do', 'does', 'doing', 'down', 'during', 'each', 'few', 'for',
  'from', 'further', 'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers', 'herself', 'him',
  'himself', 'his', 'how', 'i', 'if', 'in', 'into', 'is', 'it', 'its', 'itself', 'just', 'me',

  'more', 'most', 'my', 'myself', 'no', 'nor', 'not', 'now', 'of', 'off', 'on', 'once', 'only',
  'or', 'other', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', 'should', 'so', 'some',

  'such', 'than', 'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'these',
  'they', 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', 'we',

  'were', 'what', 'when', 'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'would', 'you',
  'your', 'yours', 'yourself', 'yourselves',

  // Additional generic / conversational words
  'please',
  'pls',
  'kindly',
  'tell',
  'telling',
  'know',
  'want',
  'wanted',
  'need',
  'needed',
  'help',
  'give',
  'get',
  'getting',
  'got',
  'make',
  'made',
  'making',
  'show',
  'showing',
  'let',
  'also',
  'really',
  'actually',
  'currently',
  'still',
  'already',
  'usually',
  'simply',
  'just',
  'thing',
  'things'
]);

// Tokenize and clean text
const tokenize = (text) => {
  if (!text) return [];
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((word) => word.length > 2 && !STOP_WORDS.has(word));
};

// Check for sensitive financial or Aadhaar data
const checkSensitiveData = (text) => {
  const aadhaarRegex = /\b\d{4}\s?\d{4}\s?\d{4}\b/;
  const cardRegex = /\b(?:\d{4}[ -]?){3}\d{4}\b/;
  const bankAccountRegex = /\b\d{9,18}\b/;

  if (aadhaarRegex.test(text) || cardRegex.test(text) || bankAccountRegex.test(text)) {
    return 'Warning: For your safety, do not share Aadhaar numbers, card details, or bank credentials in the chat.';
  }
  return null;
};

// Guess ticket category based on question keywords
const inferCategory = (question) => {
  const lower = question.toLowerCase();
  if (lower.includes('pay') || lower.includes('refund') || lower.includes('charge') || lower.includes('invoice') || lower.includes('transaction')) {
    return 'Payment issue';
  }
  if (lower.includes('kyc') || lower.includes('aadhaar') || lower.includes('pan') || lower.includes('verify') || lower.includes('document')) {
    return 'KYC issue';
  }
  if (lower.includes('login') || lower.includes('password') || lower.includes('otp') || lower.includes('email') || lower.includes('account')) {
    return 'Account issue';
  }
  if (lower.includes('project') || lower.includes('listing') || lower.includes('property') || lower.includes('builder') || lower.includes('broker')) {
    return 'Project listing';
  }
  return 'Other';
};

// Match user question against FAQs
const matchFaq = async (userQuestion) => {
  const securityWarning = checkSensitiveData(userQuestion);
  const userTokens = tokenize(userQuestion);

  // If question is too short or empty
  if (userTokens.length === 0) {
    return {
      matched: false,
      confidence: 0,
      answer: "I couldn't quite understand your question. Could you please provide more details, or raise a support ticket?",
      suggestRaiseTicket: true,
      suggestedCategory: 'Other',
      suggestedSubject: userQuestion.slice(0, 80) || 'Support Request',
      securityWarning,
    };
  }

  // Fetch all active FAQs
  const faqs = await query('SELECT * FROM faqs');

  let bestMatch = null;
  let highestScore = 0;

  for (const faq of faqs) {
    let score = 0;

    const faqQuestionTokens = tokenize(faq.question);
    const faqAnswerTokens = tokenize(faq.answer);
    const faqKeywords = (faq.keywords || '')
      .toLowerCase()
      .split(',')
      .map((k) => k.trim())
      .filter(Boolean);

    // 1. Keyword direct matching (Weight: 4.0)
    for (const token of userTokens) {
      for (const kw of faqKeywords) {
        if (kw === token || kw.includes(token) || token.includes(kw)) {
          score += 4.0;
        }
      }
    }

    // 2. Question text word overlap (Weight: 2.5)
    for (const token of userTokens) {
      if (faqQuestionTokens.includes(token)) {
        score += 2.5;
      }
    }

    // 3. Answer text overlap (Weight: 1.0)
    for (const token of userTokens) {
      if (faqAnswerTokens.includes(token)) {
        score += 1.0;
      }
    }

    // 4. Exact substring check bonus
    const cleanUserQuery = userQuestion.toLowerCase().trim();
    if (faq.question.toLowerCase().includes(cleanUserQuery) || cleanUserQuery.includes(faq.question.toLowerCase())) {
      score += 5.0;
    }

    // Normalize confidence score between 0 and 1
    const maxPossible = (userTokens.length * 4.0) + 5.0;
    const confidence = Math.min(score / maxPossible, 1.0);

    if (confidence > highestScore) {
      highestScore = confidence;
      bestMatch = {
        ...faq,
        score,
        confidence: Math.round(confidence * 100) / 100,
      };
    }
  }

  const CONFIDENCE_THRESHOLD = 0.35;

  if (bestMatch && bestMatch.confidence >= CONFIDENCE_THRESHOLD) {
    return {
      matched: true,
      confidence: bestMatch.confidence,
      faqId: bestMatch.id,
      category: bestMatch.category,
      question: bestMatch.question,
      answer: bestMatch.answer,
      suggestRaiseTicket: false,
      securityWarning,
    };
  }

  // Fallback: No adequate match found, suggest raising a ticket
  const inferredCategory = inferCategory(userQuestion);
  return {
    matched: false,
    confidence: bestMatch ? bestMatch.confidence : 0,
    answer: "I couldn't find an exact answer to your question in our knowledge base. Would you like to raise a support ticket so our team can assist you directly?",
    suggestRaiseTicket: true,
    suggestedCategory: inferredCategory,
    suggestedSubject: userQuestion.length > 80 ? userQuestion.substring(0, 77) + '...' : userQuestion,
    securityWarning,
  };
};

module.exports = {
  matchFaq,
  tokenize,
  inferCategory,
  checkSensitiveData,
};
