const { getTransporter } = require('../config/mailer');
const { escapeHtml: e } = require('../utils/escapeHtml');

const sendEmail = async ({ to, subject, html, text }) => {
  try {
    const from = process.env.EMAIL_FROM || '"Support Desk" <support@company.com>';
    const info = await getTransporter().sendMail({ from, to, subject, text, html });
    console.log(`Email sent to ${to}: "${subject}"`);
    return info;
  } catch (err) {
    // Never break an API call because an email failed
    console.error('Failed to send email:', err.message);
    return null;
  }
};

const wrap = (title, body) => `
  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
    <h2 style="color: #177c68;">${title}</h2>
    ${body}
  </div>`;

const sendTicketCreatedNotification = async (ticket, user) => {
  const subject = `[Ticket ${ticket.ticket_code}] We received your request: ${ticket.subject}`;
  const html = wrap('Ticket created', `
    <p>Hello <strong>${e(user.name)}</strong>, our team has received your ticket.</p>
    <p><strong>Ticket:</strong> ${e(ticket.ticket_code)}<br>
       <strong>Category:</strong> ${e(ticket.category)}<br>
       <strong>Subject:</strong> ${e(ticket.subject)}<br>
       <strong>Status:</strong> ${e(ticket.status)}</p>
    <p style="background:#f8fafc; padding:12px; border-left:4px solid #177c68; white-space:pre-wrap;">${e(ticket.description)}</p>
    <small style="color:#718096;">Please do not share Aadhaar, card or bank details in tickets.</small>`);
  const text = `Ticket ${ticket.ticket_code} created: ${ticket.subject}\nCategory: ${ticket.category}\n\n${ticket.description}`;

  await sendEmail({ to: user.email, subject, html, text });

  const adminEmail = process.env.ADMIN_EMAIL;
  if (adminEmail && adminEmail !== user.email) {
    await sendEmail({
      to: adminEmail,
      subject: `[New ticket] [${ticket.category}] ${ticket.ticket_code} - ${ticket.subject}`,
      html: `<p>New ticket from <strong>${e(user.name)}</strong> (${e(user.user_type)}, ${e(user.email)}):</p>${html}`,
      text: `New ticket ${ticket.ticket_code} from ${user.name} (${user.email})`,
    });
  }
};

const sendTicketReplyNotification = async (ticket, message, recipientEmail, recipientName, senderName, senderRole) => {
  const subject = `[Ticket ${ticket.ticket_code}] New reply from ${senderName}`;
  const html = wrap(`New reply on ${e(ticket.ticket_code)}`, `
    <p>Hello <strong>${e(recipientName)}</strong>, <strong>${e(senderName)}</strong> (${e(senderRole)}) replied to <em>${e(ticket.subject)}</em>:</p>
    <p style="background:#f0f4f8; padding:15px; border-radius:6px; white-space:pre-wrap;">${e(message.message)}</p>
    <p>Current status: <strong>${e(ticket.status)}</strong></p>`);
  await sendEmail({
    to: recipientEmail,
    subject,
    html,
    text: `New reply on ticket ${ticket.ticket_code} from ${senderName}:\n\n${message.message}`,
  });
};

const sendTicketStatusNotification = async (ticket, user, newStatus) => {
  const done = newStatus === 'Closed' || newStatus === 'Resolved';
  const subject = `[Ticket ${ticket.ticket_code}] Status changed to ${newStatus}`;
  const html = wrap('Ticket status updated', `
    <p>Hello <strong>${e(user.name)}</strong>, your ticket <strong>${e(ticket.ticket_code)}</strong> ("${e(ticket.subject)}") is now:</p>
    <p style="display:inline-block; padding:8px 16px; background:#e6f3f2; border-radius:20px; font-weight:bold;">${e(newStatus)}</p>
    ${done
      ? '<p>If you still need help, reply to the ticket while it is Resolved to reopen it, or raise a new ticket.</p>'
      : '<p>Our support team is working on your ticket.</p>'}`);
  await sendEmail({
    to: user.email,
    subject,
    html,
    text: `Your ticket ${ticket.ticket_code} is now ${newStatus}.`,
  });
};

module.exports = { sendTicketCreatedNotification, sendTicketReplyNotification, sendTicketStatusNotification };
