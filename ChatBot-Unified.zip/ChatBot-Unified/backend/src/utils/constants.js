// Single source of truth for values shared by tickets, FAQs and the chatbot.
const CATEGORIES = ['Account issue', 'Payment issue', 'KYC issue', 'Project listing', 'Other'];
const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'];
const SELF_SERVE_USER_TYPES = ['buyer', 'broker', 'builder']; // admins are never self-registered

module.exports = { CATEGORIES, STATUSES, SELF_SERVE_USER_TYPES };
