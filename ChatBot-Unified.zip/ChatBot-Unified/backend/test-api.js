// End-to-end API check. Uses a throw-away database, so your real data is untouched.
// Run: npm test
const path = require('path');
const os = require('os');
process.env.DB_PATH = path.join(os.tmpdir(), `support_test_${Date.now()}.sqlite`);
process.env.ADMIN_EMAIL = 'admin@support.com';
process.env.ADMIN_PASSWORD = 'Admin@123';
require('dotenv').config();

const http = require('http');
const app = require('./src/app');
const { initDb } = require('./src/config/db');
const { seedEssentials } = require('./src/database/seed');

const PORT = 5555;
let passed = 0;
let failed = 0;

const call = (method, url, body, token) =>
  new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : '';
    const req = http.request(
      { hostname: 'localhost', port: PORT, path: url, method,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data),
                   ...(token ? { Authorization: `Bearer ${token}` } : {}) } },
      (res) => {
        let raw = '';
        res.on('data', (c) => (raw += c));
        res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); } catch { resolve({ status: res.statusCode, body: raw }); } });
      }
    );
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });

const check = (name, condition) => {
  if (condition) { passed += 1; console.log(`  ok   ${name}`); }
  else { failed += 1; console.log(`  FAIL ${name}`); }
};

(async () => {
  await initDb();
  await seedEssentials();
  const server = app.listen(PORT);

  try {
    let r = await call('POST', '/api/auth/login', { email: 'admin@support.com', password: 'Admin@123' });
    check('admin can log in', r.status === 200 && r.body.data.user.user_type === 'admin');
    const admin = r.body.data;

    r = await call('POST', '/api/auth/register', { name: 'Hacker', email: 'h@x.com', password: 'secret1', user_type: 'admin' });
    check('self-registering as admin is blocked', r.status === 400);

    r = await call('POST', '/api/auth/register', { name: 'Test Buyer', email: 'buyer@test.com', password: 'secret1', user_type: 'buyer' });
    check('buyer can register', r.status === 201);
    const buyer = r.body.data;

    r = await call('GET', '/api/faqs');
    check('FAQs come from the database', r.body.data.length === 27);

    r = await call('POST', '/api/chatbot/ask', { question: 'My payment was debited but plan not activated' });
    check('chatbot matches a payment FAQ', r.body.data.matched === true && r.body.data.category === 'Payment issue');

    r = await call('POST', '/api/chatbot/ask', { question: 'zzzz qqqq xxxx' });
    check('chatbot suggests a ticket when nothing matches', r.body.data.suggestRaiseTicket === true);

    r = await call('POST', '/api/tickets', { category: 'Payment issue', subject: 'Not activated', description: 'Paid via UPI' });
    check('ticket needs login', r.status === 401);

    r = await call('POST', '/api/tickets', { category: 'Bogus', subject: 's', description: 'd' }, buyer.token);
    check('invalid category rejected', r.status === 400);

    r = await call('POST', '/api/tickets', { category: 'Payment issue', subject: 'Not activated', description: 'Paid via UPI <b>x</b>' }, buyer.token);
    check('buyer can raise a ticket', r.status === 201 && r.body.data.status === 'Open');
    const t = r.body.data;

    r = await call('GET', '/api/tickets/my', null, buyer.token);
    check('buyer sees own ticket', r.body.data.length === 1);

    r = await call('GET', '/api/tickets', null, buyer.token);
    check('buyer cannot list all tickets', r.status === 403);

    r = await call('GET', '/api/tickets?status=Open&search=activated', null, admin.token);
    check('admin lists + filters tickets', r.body.data.length === 1 && r.body.data[0].user_name === 'Test Buyer');

    r = await call('GET', '/api/users/staff', null, admin.token);
    check('admin gets staff list', r.body.data.length >= 1);
    const staffId = r.body.data[0].id;

    r = await call('PATCH', `/api/tickets/${t.id}`, { assigned_to: staffId }, admin.token);
    check('admin assigns ticket', r.body.data.assignee_name === 'Super Admin');

    r = await call('POST', `/api/tickets/${t.id}/reply`, { message: 'Checking this now' }, admin.token);
    check('admin reply moves ticket to In Progress', r.status === 201 && r.body.data.ticket_status === 'In Progress');

    r = await call('GET', '/api/tickets/my', null, buyer.token);
    check('buyer sees admin_reply_count = 1', r.body.data[0].admin_reply_count === 1);

    r = await call('PATCH', `/api/tickets/${t.id}`, { status: 'Resolved' }, admin.token);
    check('admin resolves ticket', r.body.data.status === 'Resolved');

    r = await call('POST', `/api/tickets/${t.id}/reply`, { message: 'Still not working' }, buyer.token);
    check('customer reply reopens a resolved ticket', r.body.data.ticket_status === 'Open');

    r = await call('PATCH', `/api/tickets/${t.id}`, { status: 'Closed' }, admin.token);
    r = await call('POST', `/api/tickets/${t.id}/reply`, { message: 'hello?' }, buyer.token);
    check('closed ticket rejects replies', r.status === 400);

    r = await call('GET', `/api/tickets/${t.id}`, null, buyer.token);
    check('thread has 3 messages', r.body.data.messages.length === 3);

    r = await call('GET', '/api/tickets/stats', null, admin.token);
    check('stats are counted from the database', r.body.data.total === 1 && r.body.data.Closed === 1);

    r = await call('POST', '/api/faqs', { question: 'Q?', answer: 'A', category: 'Other', keywords: 'q' }, admin.token);
    check('admin creates FAQ', r.status === 201);
    const faqId = r.body.data.id;
    r = await call('PUT', `/api/faqs/${faqId}`, { answer: 'B' }, admin.token);
    check('admin edits FAQ', r.body.data.answer === 'B');
    r = await call('DELETE', `/api/faqs/${faqId}`, null, admin.token);
    check('admin deletes FAQ', r.status === 200);
    r = await call('POST', '/api/faqs', { question: 'Q', answer: 'A', category: 'Other' }, buyer.token);
    check('customer cannot manage FAQs', r.status === 403);
  } catch (err) {
    failed += 1;
    console.error('Test crashed:', err);
  }

  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
