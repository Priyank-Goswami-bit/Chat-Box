import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService, Faq, Status, Ticket, TicketDetail, TicketStats, errorMessage } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { CATEGORIES, STATUSES } from '../core/constants';
import { UtcPipe } from '../core/utc.pipe';

interface FaqForm { id: number | null; category: string; question: string; answer: string; keywords: string; }

@Component({
  selector: 'app-admin',
  imports: [FormsModule, DatePipe, UtcPipe, RouterLink],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css',
})
export class AdminComponent implements OnInit, OnDestroy {
  private api = inject(ApiService);
  readonly auth = inject(AuthService);

  readonly statuses = STATUSES;
  readonly categories = CATEGORIES;
  readonly userTypes = [
    { value: 'buyer', label: 'Buyer' },
    { value: 'broker', label: 'Broker' },
    { value: 'builder', label: 'Builder' },
  ];
  readonly chatWarning = 'Do not share Aadhaar, card or bank details here.';

  tab: 'tickets' | 'faqs' = 'tickets';
  collapsed = window.innerWidth < 900; // sidebar starts hidden on small screens
  toast = '';
  loadError = '';
  private toastTimer?: number;
  private searchTimer?: number;
  private poll?: number;

  // tickets
  tickets: Ticket[] = [];
  stats: TicketStats = { total: 0, Open: 0, 'In Progress': 0, Resolved: 0, Closed: 0 };
  staff: { id: number; name: string }[] = [];
  loadingTickets = true;
  search = ''; fStatus = ''; fCategory = ''; fUserType = ''; fFrom = ''; fTo = '';
  selected: TicketDetail | null = null;
  selectedId: number | null = null;
  replyText = '';
  busy = false;

  // faqs
  faqs: Faq[] = [];
  faqSearch = ''; faqCategory = '';
  showFaqForm = false;
  faqForm: FaqForm = this.blankFaq();
  faqError = '';
  deleteTarget: Faq | null = null;

  ngOnInit(): void {
    this.refreshAll();
    this.api.staff().then((s) => (this.staff = s)).catch((e) => (this.loadError = errorMessage(e)));
    this.loadFaqs();
    this.poll = window.setInterval(() => this.refreshAll(), 30000);
  }

  ngOnDestroy(): void {
    window.clearInterval(this.poll);
    window.clearTimeout(this.searchTimer);
    window.clearTimeout(this.toastTimer);
  }

  get initial(): string { return (this.auth.user()?.name ?? '?').charAt(0).toUpperCase(); }

  pick(tab: 'tickets' | 'faqs'): void {
    this.tab = tab;
    if (window.innerWidth < 900) this.collapsed = true;
  }

  // ---------- tickets ----------
  get hasFilters(): boolean {
    return !!(this.search || this.fStatus || this.fCategory || this.fUserType || this.fFrom || this.fTo);
  }

  statusClass(s: string): string { return 'st-' + s.replace(' ', '-').toLowerCase(); }

  /** The first message of a thread is the ticket description, which is shown separately. */
  replies(t: TicketDetail) { return t.messages.slice(1); }

  async refreshAll(): Promise<void> {
    await Promise.all([this.loadTickets(), this.loadStats()]);
    if (this.selectedId !== null) this.loadSelected(this.selectedId);
  }

  async loadTickets(): Promise<void> {
    try {
      this.tickets = await this.api.allTickets({
        search: this.search.trim(), status: this.fStatus, category: this.fCategory,
        user_type: this.fUserType, dateFrom: this.fFrom, dateTo: this.fTo,
      });
      this.loadError = '';
    } catch (err) {
      this.loadError = errorMessage(err);
    } finally {
      this.loadingTickets = false;
    }
  }

  async loadStats(): Promise<void> {
    try { this.stats = await this.api.stats(); } catch { /* shown by loadTickets */ }
  }

  onFilterChange(debounce = false): void {
    window.clearTimeout(this.searchTimer);
    this.searchTimer = window.setTimeout(() => this.loadTickets(), debounce ? 300 : 0);
  }

  clearFilters(): void {
    this.search = this.fStatus = this.fCategory = this.fUserType = this.fFrom = this.fTo = '';
    this.onFilterChange();
  }

  async open(t: Ticket): Promise<void> {
    this.selectedId = t.id;
    this.replyText = '';
    await this.loadSelected(t.id);
  }

  private async loadSelected(id: number): Promise<void> {
    try {
      const detail = await this.api.ticket(id);
      if (this.selectedId === id) this.selected = detail;
    } catch (err) {
      this.notify(errorMessage(err));
    }
  }

  async sendReply(): Promise<void> {
    const t = this.selected;
    const text = this.replyText.trim();
    if (!t || !text || this.busy) return;
    this.busy = true;
    try {
      await this.api.reply(t.id, text);
      this.replyText = '';
      this.notify('Reply sent');
      await this.refreshAll();
    } catch (err) {
      this.notify(errorMessage(err));
    } finally {
      this.busy = false;
    }
  }

  async setStatus(status: Status): Promise<void> {
    const t = this.selected;
    if (!t || t.status === status) return;
    await this.patch(t.id, { status }, 'Status changed to ' + status);
  }

  async assign(assigneeId: number | null): Promise<void> {
    const t = this.selected;
    if (!t) return;
    const name = this.staff.find((s) => s.id === assigneeId)?.name;
    await this.patch(t.id, { assigned_to: assigneeId }, name ? 'Assigned to ' + name : 'Ticket unassigned');
  }

  private async patch(id: number, body: { status?: Status; assigned_to?: number | null }, okMessage: string): Promise<void> {
    try {
      await this.api.updateTicket(id, body);
      this.notify(okMessage);
      await this.refreshAll();
    } catch (err) {
      this.notify(errorMessage(err));
      await this.loadSelected(id); // put the dropdown back to the saved value
    }
  }

  // ---------- FAQ manager ----------
  get filteredFaqs(): Faq[] {
    const q = this.faqSearch.trim().toLowerCase();
    return this.faqs.filter((f) =>
      (!this.faqCategory || f.category === this.faqCategory) &&
      (!q || f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q)));
  }

  async loadFaqs(): Promise<void> {
    try { this.faqs = await this.api.faqs(); } catch (err) { this.loadError = errorMessage(err); }
  }

  private blankFaq(): FaqForm { return { id: null, category: CATEGORIES[0], question: '', answer: '', keywords: '' }; }
  addFaq(): void { this.faqForm = this.blankFaq(); this.faqError = ''; this.showFaqForm = true; }
  editFaq(f: Faq): void { this.faqForm = { id: f.id, category: f.category, question: f.question, answer: f.answer, keywords: f.keywords }; this.faqError = ''; this.showFaqForm = true; }
  cancelFaq(): void { this.showFaqForm = false; this.faqError = ''; }

  async saveFaq(): Promise<void> {
    const f = this.faqForm;
    const payload = { category: f.category, question: f.question.trim(), answer: f.answer.trim(), keywords: f.keywords.trim() };
    if (payload.question.length < 8 || payload.answer.length < 8) {
      this.faqError = 'Enter a question and an answer of at least 8 characters.';
      return;
    }
    try {
      if (f.id === null) await this.api.createFaq(payload);
      else await this.api.updateFaq(f.id, payload);
      this.showFaqForm = false;
      this.notify(f.id === null ? 'FAQ added' : 'FAQ updated');
      await this.loadFaqs();
    } catch (err) {
      this.faqError = errorMessage(err);
    }
  }

  async confirmDelete(): Promise<void> {
    const target = this.deleteTarget;
    this.deleteTarget = null;
    if (!target) return;
    try {
      await this.api.deleteFaq(target.id);
      this.notify('FAQ deleted');
      await this.loadFaqs();
    } catch (err) {
      this.notify(errorMessage(err));
    }
  }

  private notify(msg: string): void {
    this.toast = msg;
    window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => (this.toast = ''), 2400);
  }
}