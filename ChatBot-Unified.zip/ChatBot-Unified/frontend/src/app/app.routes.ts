import { Routes } from '@angular/router';
import { adminGuard, guestGuard } from './core/guards';

export const routes: Routes = [
  { path: '', pathMatch: 'full', loadComponent: () => import('./pages/portal/portal.component').then((m) => m.PortalComponent) },
  { path: 'login', canActivate: [guestGuard], loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent) },
  { path: 'admin', canActivate: [adminGuard], loadComponent: () => import('./admin/admin.component').then((m) => m.AdminComponent) },
  { path: '**', redirectTo: '' },
];
