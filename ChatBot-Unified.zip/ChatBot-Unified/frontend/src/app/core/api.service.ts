import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export type Status = 'Open' | 'In Progress' | 'Resolved' | 'Closed';
export type UserType = 'buyer' | 'broker' | 'builder' | 'admin';

export interface User { id: number; name: string; email: string; user_type: UserType; }
export interface Faq { id: number; question: string; answer: string; category: string; keywords: string; }
export interface Ticket {
  id: number; ticket_code: string; user_id: number; user_type: UserType; category: string;
  subject: string; description: string; status: Status; assigned_to: number | null;
  created_at: string; updated_at: string;
  user_name?: string; user_email?: string; assignee_name?: string | null; admin_reply_count?: number;
}
export interface TicketMessage {
  id: number; ticket_id: number; sender_id: number; sender_role: 'user' | 'admin';
  sender_name: string; message: string; created_at: string;
}
export interface TicketDetail extends Ticket { messages: TicketMessage[]; }
export interface TicketStats { total: number; Open: number; 'In Progress': number; Resolved: number; Closed: number; }
export interface TicketFilters {
  search?: string; status?: string; category?: string; user_type?: string; dateFrom?: string; dateTo?: string;
}
export interface BotReply {
  matched: boolean; answer: string; suggestRaiseTicket: boolean;
  suggestedCategory?: string; suggestedSubject?: string; securityWarning: string | null;
}
export interface AuthResult { user: User; token: string; }

interface Envelope<T> { success: boolean; message: string; data: T; }

/** Turns any HTTP error into a short message that can be shown to the person. */
export function errorMessage(err: unknown): string {
  if (err instanceof HttpErrorResponse) {
    if (err.status === 0) return 'Cannot reach the server. Check that the backend is running.';
    return err.error?.message ?? 'Something went wrong. Please try again.';
  }
  return 'Something went wrong. Please try again.';
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);

  private async get<T>(url: string, params?: Record<string, string | undefined>): Promise<T> {
    let httpParams = new HttpParams();
    Object.entries(params ?? {}).forEach(([k, v]) => { if (v) httpParams = httpParams.set(k, v); });
    return (await firstValueFrom(this.http.get<Envelope<T>>(url, { params: httpParams }))).data;
  }
  private async send<T>(method: 'post' | 'put' | 'patch' | 'delete', url: string, body?: unknown): Promise<T> {
    return (await firstValueFrom(this.http.request<Envelope<T>>(method, url, { body }))).data;
  }

  // auth
  login(email: string, password: string) { return this.send<AuthResult>('post', '/api/auth/login', { email, password }); }
  register(body: { name: string; email: string; password: string; user_type: string }) {
    return this.send<AuthResult>('post', '/api/auth/register', body);
  }
  me() { return this.get<{ user: User }>('/api/auth/me'); }

  // chatbot + FAQs
  ask(question: string) { return this.send<BotReply>('post', '/api/chatbot/ask', { question }); }
  faqs(category?: string) { return this.get<Faq[]>('/api/faqs', { category }); }
  createFaq(f: Pick<Faq, 'question' | 'answer' | 'category' | 'keywords'>) { return this.send<Faq>('post', '/api/faqs', f); }
  updateFaq(id: number, f: Pick<Faq, 'question' | 'answer' | 'category' | 'keywords'>) { return this.send<Faq>('put', `/api/faqs/${id}`, f); }
  deleteFaq(id: number) { return this.send<{ id: number }>('delete', `/api/faqs/${id}`); }

  // customer tickets
  createTicket(b: { category: string; subject: string; description: string }) { return this.send<Ticket>('post', '/api/tickets', b); }
  myTickets() { return this.get<Ticket[]>('/api/tickets/my'); }

  // shared
  ticket(id: number) { return this.get<TicketDetail>(`/api/tickets/${id}`); }
  reply(id: number, message: string) { return this.send<TicketMessage & { ticket_status: Status }>('post', `/api/tickets/${id}/reply`, { message }); }

  // admin
  allTickets(f: TicketFilters) { return this.get<Ticket[]>('/api/tickets', { ...f }); }
  stats() { return this.get<TicketStats>('/api/tickets/stats'); }
  staff() { return this.get<{ id: number; name: string }[]>('/api/users/staff'); }
  updateTicket(id: number, patch: { status?: Status; assigned_to?: number | null }) { return this.send<Ticket>('patch', `/api/tickets/${id}`, patch); }
}
