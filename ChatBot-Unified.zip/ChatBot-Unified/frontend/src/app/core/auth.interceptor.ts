import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.token;
  const authed = token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(authed).pipe(
    catchError((err: unknown) => {
      // An expired or invalid session sends the person back to the login page
      const isLoginCall = req.url.includes('/api/auth/login') || req.url.includes('/api/auth/register');
      if (err instanceof HttpErrorResponse && err.status === 401 && token && !isLoginCall) {
        auth.logout();
      }
      return throwError(() => err);
    })
  );
};
