import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService, AuthResult, User } from './api.service';

const TOKEN_KEY = 'support.token';
const USER_KEY = 'support.user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = inject(ApiService);
  private router = inject(Router);

  readonly user = signal<User | null>(this.readUser());
  readonly isAdmin = computed(() => this.user()?.user_type === 'admin');

  get token(): string | null { return localStorage.getItem(TOKEN_KEY); }

  async login(email: string, password: string): Promise<User> {
    return this.store(await this.api.login(email, password));
  }
  async register(body: { name: string; email: string; password: string; user_type: string }): Promise<User> {
    return this.store(await this.api.register(body));
  }

  logout(redirect = true): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this.user.set(null);
    if (redirect) this.router.navigateByUrl('/login');
  }

  /** Where this person should land after logging in. */
  homeFor(user: User): string { return user.user_type === 'admin' ? '/admin' : '/'; }

  private store(result: AuthResult): User {
    localStorage.setItem(TOKEN_KEY, result.token);
    localStorage.setItem(USER_KEY, JSON.stringify(result.user));
    this.user.set(result.user);
    return result.user;
  }

  private readUser(): User | null {
    try {
      return localStorage.getItem(TOKEN_KEY) ? JSON.parse(localStorage.getItem(USER_KEY) ?? 'null') : null;
    } catch { return null; }
  }
}
