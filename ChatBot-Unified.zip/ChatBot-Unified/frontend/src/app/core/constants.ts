// Must match backend/src/utils/constants.js
export const CATEGORIES = ['Account issue', 'Payment issue', 'KYC issue', 'Project listing', 'Other'] as const;
export const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'] as const;
export const USER_TYPES = ['buyer', 'broker', 'builder'] as const;
