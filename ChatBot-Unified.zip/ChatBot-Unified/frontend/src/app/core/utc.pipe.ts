import { Pipe, PipeTransform } from '@angular/core';

/** The database stores UTC times as "2026-10-07 09:12:00". This turns them into a real Date for the date pipe. */
@Pipe({ name: 'utc', standalone: true })
export class UtcPipe implements PipeTransform {
  transform(value: string | null | undefined): Date | null {
    if (!value) return null;
    return new Date(value.includes('T') ? value : value.replace(' ', 'T') + 'Z');
  }
}
