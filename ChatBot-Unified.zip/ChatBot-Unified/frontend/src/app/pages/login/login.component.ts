import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { errorMessage } from '../../core/api.service';
import { USER_TYPES } from '../../core/constants';

@Component({
  selector: 'app-login',
  imports: [FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  readonly userTypes = USER_TYPES;
  mode: 'login' | 'register' = 'login';
  form = { name: '', email: '', password: '', user_type: 'buyer' as string };
  error = '';
  busy = false;
  showPassword = false;

  setMode(mode: 'login' | 'register'): void {
    this.mode = mode;
    this.error = '';
  }

  async submit(): Promise<void> {
    this.error = '';
    this.busy = true;
    try {
      const user = this.mode === 'login'
        ? await this.auth.login(this.form.email, this.form.password)
        : await this.auth.register(this.form);
      await this.router.navigateByUrl(this.auth.homeFor(user));
    } catch (err) {
      this.error = errorMessage(err);
    } finally {
      this.busy = false;
    }
  }
}