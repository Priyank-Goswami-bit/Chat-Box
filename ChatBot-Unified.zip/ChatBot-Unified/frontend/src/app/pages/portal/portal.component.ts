import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { ChatWidgetComponent } from '../../widget/chat-widget.component';

@Component({
  selector: 'app-portal',
  imports: [RouterLink, ChatWidgetComponent],
  templateUrl: './portal.component.html',
  styleUrl: './portal.component.css',
})
export class PortalComponent {
  readonly auth = inject(AuthService);
}
