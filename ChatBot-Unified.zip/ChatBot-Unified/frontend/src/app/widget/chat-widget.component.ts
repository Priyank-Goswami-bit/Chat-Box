import { DatePipe } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, OnDestroy, OnInit, ViewChild, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import 'emoji-picker-element';
import { ApiService, Faq, Ticket, TicketDetail, errorMessage } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { CATEGORIES } from '../core/constants';
import { UtcPipe } from '../core/utc.pipe';

interface ChatMessage {
  sender: 'customer' | 'support';
  body: string;
  createdAt: Date;
  faqChoices?: Faq[];
  ticketPrompt?: { category: string; subject: string };
  warning?: string | null;
}

type View = 'chat' | 'ticket' | 'submitted' | 'my' | 'detail' | 'login';

@Component({
  selector: 'app-chat-widget',
  imports: [FormsModule, DatePipe, UtcPipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './chat-widget.component.html',
  styleUrl: './chat-widget.component.css',
})
export class ChatWidgetComponent implements OnInit, OnDestroy {
  private api = inject(ApiService);
  readonly auth = inject(AuthService);
  private router = inject(Router);

  @ViewChild('chatBody') chatBody?: ElementRef<HTMLElement>;

  readonly categories = CATEGORIES;
  chatOpen = false;
  activeView: View = 'chat';

  // chat
  chatDraft = '';
  showEmojiPicker = false;
  messages: ChatMessage[] = [];
  typing = false;

  // raise ticket
  ticketDraft = { category: '', subject: '', description: '' };
  ticketBusy = false;
  ticketError = '';
  submittedCode = '';

  // my tickets
  tickets: Ticket[] = [];
  ticketsLoading = false;
  ticketsError = '';
  selected: TicketDetail | null = null;
  detailError = '';
  replyDraft = '';
  replyBusy = false;

  // unread replies from support
  unreadReplyCount = 0;
  private seen: Record<string, number> = {};
  private poll?: number;

  ngOnInit(): void {
    if (this.auth.user()) {
      this.refreshUnread();
      this.poll = window.setInterval(() => this.refreshUnread(), 30000);
    }
  }

  ngOnDestroy(): void {
    if (this.poll) window.clearInterval(this.poll);
  }

  get title(): string {
    switch (this.activeView) {
      case 'ticket': return 'Raise a ticket';
      case 'submitted': return 'Ticket submitted';
      case 'my': return 'My tickets';
      case 'detail': return this.selected?.ticket_code ?? 'Ticket';
      case 'login': return 'Log in';
      default: return 'searchbhoomi';
    }
  }

  toggleChat(): void {
    this.chatOpen = !this.chatOpen;
    if (this.chatOpen && this.auth.user()) this.refreshUnread();
  }

  // ---------------- chat ----------------
  async selectCategory(category: string): Promise<void> {
    this.addMessage({ sender: 'customer', body: category });
    this.typing = true;
    try {
      const faqs = await this.api.faqs(category);
      if (faqs.length) {
        this.addMessage({ sender: 'support', body: `Here are common questions about ${category.toLowerCase()}. Pick one, or type your own question below.`, faqChoices: faqs });
      } else {
        this.addMessage({ sender: 'support', body: 'I have no ready answers for this topic yet. You can type your question or raise a ticket.', ticketPrompt: { category, subject: '' } });
      }
    } catch (err) {
      this.addMessage({ sender: 'support', body: errorMessage(err) });
    } finally {
      this.typing = false;
    }
  }

  chooseFaq(faq: Faq): void {
    this.addMessage({ sender: 'customer', body: faq.question });
    this.addMessage({ sender: 'support', body: faq.answer });
  }

  async sendChatMessage(): Promise<void> {
    const body = this.chatDraft.trim();
    if (!body || this.typing) return;
    this.addMessage({ sender: 'customer', body });
    this.chatDraft = '';
    this.showEmojiPicker = false;
    this.typing = true;
    try {
      const reply = await this.api.ask(body);
      this.addMessage({
        sender: 'support',
        body: reply.answer,
        warning: reply.securityWarning,
        ticketPrompt: reply.suggestRaiseTicket
          ? { category: reply.suggestedCategory ?? 'Other', subject: reply.suggestedSubject ?? '' }
          : undefined,
      });
    } catch (err) {
      this.addMessage({ sender: 'support', body: errorMessage(err) });
    } finally {
      this.typing = false;
    }
  }

  onChatKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendChatMessage();
    }
  }

  addEmoji(event: Event): void {
    const emoji = (event as CustomEvent<{ unicode: string }>).detail?.unicode;
    if (emoji) this.chatDraft += emoji;
    this.showEmojiPicker = false;
  }

  // ---------------- raise ticket ----------------
  showTicketForm(prefill?: { category: string; subject: string }): void {
    if (!this.auth.user()) { this.activeView = 'login'; return; }
    this.ticketError = '';
    if (prefill) this.ticketDraft = { category: prefill.category, subject: prefill.subject, description: '' };
    this.activeView = 'ticket';
  }

  async submitTicket(): Promise<void> {
    this.ticketError = '';
    this.ticketBusy = true;
    try {
      const ticket = await this.api.createTicket(this.ticketDraft);
      this.submittedCode = ticket.ticket_code;
      this.ticketDraft = { category: '', subject: '', description: '' };
      this.activeView = 'submitted';
    } catch (err) {
      this.ticketError = errorMessage(err);
    } finally {
      this.ticketBusy = false;
    }
  }

  goLogin(): void {
    this.router.navigateByUrl('/login');
  }

  // ---------------- my tickets ----------------
  async openMyTickets(): Promise<void> {
    if (!this.auth.user()) { this.activeView = 'login'; return; }
    this.activeView = 'my';
    this.ticketsLoading = true;
    this.ticketsError = '';
    try {
      this.tickets = await this.api.myTickets();
      this.updateUnread();
    } catch (err) {
      this.ticketsError = errorMessage(err);
    } finally {
      this.ticketsLoading = false;
    }
  }

  async openTicket(t: Ticket): Promise<void> {
    this.activeView = 'detail';
    this.selected = null;
    this.detailError = '';
    this.replyDraft = '';
    try {
      this.selected = await this.api.ticket(t.id);
      this.markSeen(this.selected);
    } catch (err) {
      this.detailError = errorMessage(err);
    }
  }

  async sendTicketReply(): Promise<void> {
    const text = this.replyDraft.trim();
    if (!text || !this.selected || this.replyBusy) return;
    this.replyBusy = true;
    this.detailError = '';
    try {
      await this.api.reply(this.selected.id, text);
      this.replyDraft = '';
      this.selected = await this.api.ticket(this.selected.id);
      this.markSeen(this.selected);
    } catch (err) {
      this.detailError = errorMessage(err);
    } finally {
      this.replyBusy = false;
    }
  }

  onReplyKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendTicketReply();
    }
  }

  isUnread(t: Ticket): boolean {
    return (t.admin_reply_count ?? 0) > (this.seen[t.id] ?? 0);
  }

  // ---------------- unread replies ----------------
  private get seenKey(): string { return `support.seen.${this.auth.user()?.id}`; }

  private loadSeen(): void {
    try { this.seen = JSON.parse(localStorage.getItem(this.seenKey) ?? '{}'); } catch { this.seen = {}; }
  }

  private async refreshUnread(): Promise<void> {
    try {
      this.tickets = await this.api.myTickets();
      this.updateUnread();
    } catch { /* badge is optional; ignore network hiccups */ }
  }

  private updateUnread(): void {
    this.loadSeen();
    this.unreadReplyCount = this.tickets.filter((t) => this.isUnread(t)).length;
  }

  private markSeen(ticket: TicketDetail): void {
    this.loadSeen();
    this.seen[ticket.id] = ticket.messages.filter((m) => m.sender_role === 'admin').length;
    localStorage.setItem(this.seenKey, JSON.stringify(this.seen));
    this.updateUnread();
  }

  // ---------------- helpers ----------------
  private addMessage(m: Omit<ChatMessage, 'createdAt'>): void {
    this.messages.push({ ...m, createdAt: new Date() });
    window.setTimeout(() => {
      const el = this.chatBody?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }

  statusClass(s: string): string {
    return 'st-' + s.replace(' ', '-').toLowerCase();
  }
}
